
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ByteToolkit.h>
#include <qcat_dataAnalysis.h>
#include <qcat_compressionAnalysis.h>
#include <sz_dummy_compression.h>
#include <Huffman.h>
#include <zstd.h>
#include <qcat_ssim.h>

#ifndef _QCAT_H
#define _QCAT_H

#define MAJOR_VERSION 1
#define MINOR_VERSION 7
#define REVISION_VERSION 0

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* ----- #ifndef _QCAT_H  ----- */
